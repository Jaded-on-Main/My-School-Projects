// Basics of POD.cpp
//

#include <iostream>
using namespace std;

#define PWATCH(var) cout << "{  " #var " = " << var << " : " << &var << " : " << sizeof var << "}\n";

int main()
{   // sizeof = the amount of bytes used

    int i{ 42 };
    PWATCH(i);
    int j{ i };
    PWATCH(j);
    const int k{ i };
    PWATCH(k);
    const int ce{ 42 };
    PWATCH(ce);
    cout << endl;

    // POD pointers
    int* p{ &i };   // * following a data type makes it a pointer to that data type
    PWATCH(i);
        PWATCH(p);
        int** pp{ &p };
        PWATCH(pp);
    // modify 'i' via 'p'
        *p = 100;       // '*p' says 'follow the pointer' or formally 'dereference' the pointer
        PWATCH(i);
            PWATCH(p);

    // move 'p'
    p = &j;
    *p = 43;
    PWATCH(i);
    PWATCH(j);
    PWATCH(p);

    /*p = nullptr;
    *p = 911;
    PWATCH(p);*/

    // array POD
    constexpr size_t aSize{ 10 };
    int a[aSize]{ 11,12,13,14,15,16,17 };
    PWATCH(a);
    PWATCH(a[0]);
    PWATCH(*a);
    PWATCH(a[3]);
    p = a;
    PWATCH(*p);
    ++p;
    PWATCH(*p);
    p += 2;
    PWATCH(*p);


    // Index print 
    for (size_t i{}; i < aSize; ++i)
        cout << a[i] << ", ";           // a[i] = *(a+i*sizeof(int))        C O(3n)     Java 0(13n)
    cout << endl;

    // pointer print
    auto pend{ a + aSize };     // 2 op
    p = a;                      // 1 op
    while (p < pend)            // 1n
        cout << *p++ << ", ";   // 1n
    cout << endl;               // total 3+3n


    //c-string (not c++) are POD
    char szMessage[]{ 'H' , 'e', 'l', 'l', 'o', '\0' };
    // C-Styel strings are arrays of char with ASCII character zero at the end 
    PWATCH(szMessage);
    const char* szOtherMessage{ " Goodbye" };
    PWATCH(szOtherMessage);
    
    // c- structures are POD (if their elements are POD)
    struct point
    {
        float x;
        float y;
    };

    point origin{ 0,0 };
    origin.x = origin.y = 0;
    PWATCH(origin.x);
    PWATCH(origin.y);
    point other{ 3,4 };
    PWATCH(other.x);
    PWATCH(other.y);
    cout << "{ orgin = " << &origin << " : " << sizeof(point) << "}\n";

    auto distance = [](auto first, auto second) {
        auto dx{ second.x - first.x };
        auto dy{ second.y - first.y };
        return std::sqrt(dx * dx + dy * dy);
        };
    auto dist = distance(origin, other);
    PWATCH(dist);
}


